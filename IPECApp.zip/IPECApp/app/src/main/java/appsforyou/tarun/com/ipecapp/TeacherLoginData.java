package appsforyou.tarun.com.ipecapp;

public class TeacherLoginData  {
    String teacherid;
    String password;
}
